// ============================================================
//  tour-data-sync.js  v2.0
//
//  Works on every tour-*.html page automatically.
//
//  Logic (in order of priority):
//    1. Always apply STATIC_TOURS baseline (correct Unsplash images,
//       correct titles/subtitles) — no dependency on admin saving
//    2. If admin has saved overrides via API → overlay on top
//
//  This guarantees tour pages ALWAYS match what admin sees,
//  even before admin clicks "Save" for a specific tour.
//
//  Requires: js/tours-config.js loaded BEFORE this script
// ============================================================

(function () {
    'use strict';

    // ── Derive slug from current page filename ─────────────────
    var pageSlug = location.pathname
        .split('/').pop()
        .replace(/\.html$/i, '');

    if (!pageSlug || !pageSlug.startsWith('tour-')) return;

    // ── Helpers ───────────────────────────────────────────────
    function qs(sel) { return document.querySelector(sel); }

    function setTextSafe(sel, text) {
        var el = qs(sel);
        if (el && text) el.textContent = text;
    }

    function formatPrice(adult, child) {
        var parts = [];
        if (adult && adult > 0) parts.push('Adult: $' + adult);
        if (child  && child  > 0) parts.push('Child: $' + child);
        return parts.length ? parts.join(' / ') : 'Price on request';
    }

    // ── Apply data object to page DOM ─────────────────────────
    function applyTourData(rec) {

        // 1. Hero background image (always replace broken sspark CDN)
        if (rec.image_url) {
            var heroSection = qs('section.tour-hero');
            if (heroSection) {
                heroSection.style.background =
                    'linear-gradient(rgba(0,0,0,0.40), rgba(0,0,0,0.50)), ' +
                    'url("' + rec.image_url + '") center/cover no-repeat';
            }
        }

        // 2. Tour title
        if (rec.title) {
            setTextSafe('.tour-hero__title', rec.title);
            var baseTitle = document.title.split('|').slice(1).join('|').trim();
            document.title = rec.title + (baseTitle ? ' | ' + baseTitle : ' | Gettravel');
        }

        // 3. Tour subtitle
        if (rec.subtitle) {
            setTextSafe('.tour-hero__subtitle', rec.subtitle);
        }

        // 4. Price block
        var priceText = formatPrice(rec.adult_price, rec.child_price);
        var priceEl = qs('.tour-price, .price-display, [data-price]');
        if (priceEl) {
            priceEl.textContent = priceText;
        } else if (rec.adult_price > 0 || rec.child_price > 0) {
            var subtitle = qs('.tour-hero__subtitle');
            if (subtitle) {
                // Remove existing badge if re-applying
                var existingBadge = qs('.tour-price-badge');
                if (existingBadge) existingBadge.remove();

                var badge = document.createElement('div');
                badge.className = 'tour-price-badge';
                badge.style.cssText = [
                    'display:inline-block',
                    'margin-top:12px',
                    'background:rgba(255,255,255,0.18)',
                    'border:1.5px solid rgba(255,255,255,0.45)',
                    'backdrop-filter:blur(6px)',
                    'color:#fff',
                    'font-size:1.05rem',
                    'font-weight:700',
                    'padding:8px 22px',
                    'border-radius:30px',
                    'letter-spacing:.4px'
                ].join(';');
                badge.textContent = priceText;
                subtitle.insertAdjacentElement('afterend', badge);
            }
        }

        // 5. Meta description
        if (rec.description) {
            var metaDesc = document.querySelector('meta[name="description"]');
            if (metaDesc) metaDesc.setAttribute('content', rec.description);
        }

        // 6. Update WhatsApp booking links
        document.querySelectorAll('a[href*="wa.me"]').forEach(function (a) {
            var base = 'https://wa.me/84797722507?text=';
            var msg  = 'Hello! I would like to book: ' + (rec.title || pageSlug);
            if (rec.adult_price > 0) msg += ' (' + priceText + ')';
            a.href = base + encodeURIComponent(msg);
        });

        // 7. Draft/inactive warning (admin only)
        if (rec.status && rec.status !== 'active') {
            if (sessionStorage.getItem('adminLoggedIn')) {
                var banner = document.createElement('div');
                banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9000;' +
                    'background:#f59e0b;color:#1a1a1a;text-align:center;' +
                    'padding:8px 16px;font-size:13px;font-weight:700;';
                banner.textContent = '⚠️ Tour status: "' + rec.status + '" — not visible to public.';
                document.body.prepend(banner);
            }
        }
    }

    // ── Main sync function ────────────────────────────────────
    async function syncTourData() {
        // STEP 1: Find static baseline from tours-config.js
        // This fixes broken sspark CDN images on ALL tour pages immediately,
        // no admin action required.
        var staticRec = null;
        if (typeof STATIC_TOURS !== 'undefined') {
            staticRec = STATIC_TOURS.find(function (t) { return t.id === pageSlug; });
        }

        // Apply static baseline first (guaranteed correct images + titles)
        if (staticRec) {
            applyTourData(staticRec);
        }

        // STEP 2: Try to fetch admin overrides from API
        // If admin has saved changes → overlay on top of static baseline
        try {
            var res = await fetch('tables/tours?limit=200');
            if (!res.ok) return;
            var data = await res.json();
            var list = data.data || [];

            var apiRec = list.find(function (r) { return r.slug === pageSlug; });
            if (apiRec) {
                // Merge: static baseline + API overrides
                // API values win only when they are non-empty
                var merged = {};
                if (staticRec) {
                    merged = Object.assign({}, staticRec);
                }
                // Override only fields that admin actually set
                ['title', 'subtitle', 'description', 'image_url', 'duration',
                 'category', 'status', 'adult_price', 'child_price'].forEach(function (f) {
                    if (apiRec[f] !== undefined && apiRec[f] !== null && apiRec[f] !== '') {
                        merged[f] = apiRec[f];
                    }
                });
                applyTourData(merged);
            }
        } catch (e) {
            // Silent fail — page already has static baseline applied
        }
    }

    // ── Run after DOM is ready ────────────────────────────────
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', syncTourData);
    } else {
        syncTourData();
    }

})();
