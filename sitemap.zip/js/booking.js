// ==================== BOOKING SYSTEM WITH TABLE API ====================

// Booking form submission handler
const bookingForms = document.querySelectorAll('#bookingForm, #contactForm');

bookingForms.forEach(form => {
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(form);
        const data = {
            customer_name: formData.get('name'),
            customer_phone: formData.get('phone'),
            customer_email: formData.get('email') || '',
            tour_name: formData.get('tour') || document.title.split('|')[0].trim(),
            tour_date: formData.get('tourDate') || '',
            adults: parseInt(formData.get('adults')) || 0,
            children: parseInt(formData.get('children')) || 0,
            message: formData.get('message') || '',
            language: getCurrentLanguage(),
            status: 'pending',
            total_price: calculateTotalPrice()
        };

        // Validate required fields
        if (!data.customer_name || !data.customer_phone) {
            showNotification('error', 'Please fill in all required fields.');
            return;
        }

        // Show loading
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

        try {
            // Send booking to Table API
            const response = await fetch('tables/bookings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                const result = await response.json();
                
                // Show success message
                showNotification('success', 'Your booking request has been sent! We will contact you shortly.');
                
                // Reset form
                form.reset();
                
                // Send notification via WhatsApp (optional)
                sendWhatsAppNotification(data);
                
                // Redirect to thank you message after 2 seconds
                setTimeout(() => {
                    if (form.id === 'bookingForm') {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    }
                }, 2000);
            } else {
                throw new Error('Submission error');
            }
        } catch (error) {
            console.error('Booking error:', error);
            showNotification('error', 'An error occurred. Please contact us directly: +84 79 772 2507');
        } finally {
            // Restore button
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
});

// Calculate total price (if price fields exist)
function calculateTotalPrice() {
    const adultPrice = parseInt(document.body.getAttribute('data-adult-price')) || 0;
    const childPrice = parseInt(document.body.getAttribute('data-child-price')) || 0;
    const adults = parseInt(document.getElementById('adults')?.value) || 0;
    const children = parseInt(document.getElementById('children')?.value) || 0;
    
    return (adults * adultPrice) + (children * childPrice);
}

// Show notification
function showNotification(type, message) {
    // Remove existing notifications
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.innerHTML = `
        <div class="notification__content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="notification__close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add to page
    document.body.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.classList.add('notification--fadeout');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Send WhatsApp notification (opens WhatsApp with pre-filled message)
function sendWhatsAppNotification(data) {
    const message = `
🎉 New Booking Request!

👤 Name: ${data.customer_name}
📞 Phone: ${data.customer_phone}
📧 Email: ${data.customer_email || 'not provided'}
🎫 Tour: ${data.tour_name}
📅 Date: ${data.tour_date || 'not specified'}
👥 Adults: ${data.adults}
👶 Children: ${data.children}
💬 Message: ${data.message || 'none'}
🌐 Language: ${data.language}
    `.trim();

    // This could be automated to send to your business WhatsApp
    console.log('WhatsApp notification:', message);
}

// Get current language
function getCurrentLanguage() {
    return document.getElementById('currentLang')?.textContent || 'EN';
}

// ==================== ADD NOTIFICATION STYLES ====================
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification {
        position: fixed;
        top: 100px;
        right: 30px;
        min-width: 300px;
        max-width: 500px;
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    }

    .notification--success {
        border-left: 4px solid #28a745;
    }

    .notification--error {
        border-left: 4px solid #dc3545;
    }

    .notification__content {
        display: flex;
        align-items: center;
        gap: 12px;
        flex: 1;
    }

    .notification--success .notification__content i {
        color: #28a745;
        font-size: 1.5rem;
    }

    .notification--error .notification__content i {
        color: #dc3545;
        font-size: 1.5rem;
    }

    .notification__close {
        background: none;
        border: none;
        color: #666;
        cursor: pointer;
        font-size: 1.2rem;
        padding: 5px;
        transition: color 0.3s;
    }

    .notification__close:hover {
        color: #333;
    }

    .notification--fadeout {
        animation: slideOut 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }

    @media screen and (max-width: 768px) {
        .notification {
            right: 10px;
            left: 10px;
            min-width: auto;
        }
    }
`;
document.head.appendChild(notificationStyles);

// ==================== LOAD BOOKINGS (ADMIN VIEW) ====================
async function loadBookings(page = 1, limit = 10) {
    try {
        const response = await fetch(`tables/bookings?page=${page}&limit=${limit}&sort=-created_at`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error loading bookings:', error);
        return null;
    }
}

// ==================== UPDATE BOOKING STATUS ====================
async function updateBookingStatus(bookingId, newStatus) {
    try {
        const response = await fetch(`tables/bookings/${bookingId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (response.ok) {
            console.log('Booking status updated successfully');
            return true;
        }
        return false;
    } catch (error) {
        console.error('Error updating booking:', error);
        return false;
    }
}

// ==================== GET BOOKING BY ID ====================
async function getBooking(bookingId) {
    try {
        const response = await fetch(`tables/bookings/${bookingId}`);
        if (response.ok) {
            return await response.json();
        }
        return null;
    } catch (error) {
        console.error('Error getting booking:', error);
        return null;
    }
}

console.log('✅ Booking system initialized with Table API');