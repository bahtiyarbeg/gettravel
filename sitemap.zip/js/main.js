// ==================== NAVIGATION MENU ====================
const navMenu = document.getElementById('nav-menu');
const navToggle = document.getElementById('nav-toggle');
const navClose = document.getElementById('nav-close');

// Show menu
if (navToggle) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-menu');
    });
}

// Hide menu
if (navClose) {
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-menu');
    });
}

// Close menu when clicking on nav links
const navLinks = document.querySelectorAll('.nav__link');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('show-menu');
    });
});

// ==================== SCROLL HEADER ====================
function scrollHeader() {
    const header = document.getElementById('header');
    if (!header) return;
    if (window.scrollY >= 80) {
        header.classList.add('scroll-header');
    } else {
        header.classList.remove('scroll-header');
    }
}
window.addEventListener('scroll', scrollHeader);

// ==================== SCROLL TOP ====================
function scrollTop() {
    const scrollTopEl = document.getElementById('scroll-top');
    if (!scrollTopEl) return;
    if (window.scrollY >= 400) {
        scrollTopEl.classList.add('show');
    } else {
        scrollTopEl.classList.remove('show');
    }
}
window.addEventListener('scroll', scrollTop);

// Scroll to top on click
const scrollTopBtn = document.getElementById('scroll-top');
if (scrollTopBtn) {
    scrollTopBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// ==================== SMOOTH SCROLL ====================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && document.querySelector(href)) {
            e.preventDefault();
            const target = document.querySelector(href);
            const headerOffset = 80;
            const elementPosition = target.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// ==================== CONTACT FORM ====================
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Collect form data
        const formData = new FormData(contactForm);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        
        // Show success message
        alert('Thank you for your message! We will contact you shortly.');
        
        // Reset form
        contactForm.reset();
        
        // In a real application, you would send the data to a server here
        console.log('Form data:', data);
    });
}

// ==================== TOUR FILTERS ====================
const filterBtns = document.querySelectorAll('.filter-btn');
const tourCards = document.querySelectorAll('.tour-card');

if (filterBtns.length > 0 && tourCards.length > 0) {
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons
            filterBtns.forEach(b => b.classList.remove('active'));
            // Add active class to clicked button
            btn.classList.add('active');
            
            const filter = btn.getAttribute('data-filter');
            
            tourCards.forEach(card => {
                if (filter === 'all') {
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'scale(1)';
                    }, 10);
                } else {
                    const category = card.getAttribute('data-category');
                    if (category === filter) {
                        card.style.display = 'block';
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'scale(1)';
                        }, 10);
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'scale(0.8)';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 300);
                    }
                }
            });
        });
    });
}

// Check URL for category filter
window.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    
    if (category && filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            if (btn.getAttribute('data-filter') === category) {
                btn.click();
            }
        });
    }
});

// ==================== BOOKING FORM ====================
const bookingForm = document.getElementById('bookingForm');
if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Collect form data
        const formData = new FormData(bookingForm);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        
        // Show success message
        alert('Your booking request has been received! We will contact you within 30 minutes to confirm the details.');
        
        // Reset form
        bookingForm.reset();
        
        // Scroll to top
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
        
        // In a real application, you would send the data to a server here
        console.log('Booking data:', data);
    });
}

// ==================== ANIMATIONS ====================
// Simple scroll animation
const animateOnScroll = () => {
    const elements = document.querySelectorAll('[data-aos]');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
};

// Initialize animation styles
document.querySelectorAll('[data-aos]').forEach(element => {
    element.style.opacity = '0';
    element.style.transform = 'translateY(30px)';
    element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
});

window.addEventListener('scroll', animateOnScroll);
window.addEventListener('DOMContentLoaded', animateOnScroll);

// ==================== TOUR DETAILS GALLERY ====================
const galleryThumbnails = document.querySelectorAll('.gallery__thumbnail');
const mainImage = document.querySelector('.tour-detail__main-image img');

if (galleryThumbnails.length > 0 && mainImage) {
    galleryThumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', () => {
            // Remove active class from all thumbnails
            galleryThumbnails.forEach(t => t.classList.remove('active'));
            // Add active class to clicked thumbnail
            thumbnail.classList.add('active');
            
            // Change main image
            const newSrc = thumbnail.getAttribute('data-image');
            mainImage.style.opacity = '0';
            setTimeout(() => {
                mainImage.src = newSrc;
                mainImage.style.opacity = '1';
            }, 300);
        });
    });
}

// ==================== ACCORDION ====================
const accordionItems = document.querySelectorAll('.accordion__item');

accordionItems.forEach(item => {
    const header = item.querySelector('.accordion__header');
    if (!header) return;
    
    header.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        
        // Close all items
        accordionItems.forEach(i => {
            i.classList.remove('active');
            const content = i.querySelector('.accordion__content');
            content.style.maxHeight = null;
        });
        
        // Open clicked item if it wasn't active
        if (!isActive) {
            item.classList.add('active');
            const content = item.querySelector('.accordion__content');
            content.style.maxHeight = content.scrollHeight + 'px';
        }
    });
});

// ==================== PRICE CALCULATOR ====================
const adultsInput = document.getElementById('adults');
const childrenInput = document.getElementById('children');
const dateInput = document.getElementById('tourDate');
const totalPriceElement = document.getElementById('totalPrice');

function calculatePrice() {
    if (!adultsInput || !childrenInput || !totalPriceElement) return;
    
    const adults = parseInt(adultsInput.value) || 0;
    const children = parseInt(childrenInput.value) || 0;
    
    // Get price from data attribute (set in tour detail pages)
    const adultPrice = parseInt(document.body.getAttribute('data-adult-price')) || 0;
    const childPrice = parseInt(document.body.getAttribute('data-child-price')) || 0;
    
    const total = (adults * adultPrice) + (children * childPrice);
    
    totalPriceElement.textContent = `$${total}`;
}

if (adultsInput && childrenInput) {
    adultsInput.addEventListener('input', calculatePrice);
    childrenInput.addEventListener('input', calculatePrice);
}

// ==================== LAZY LOADING IMAGES ====================
const lazyImages = document.querySelectorAll('img[data-src]');

const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.getAttribute('data-src');
            img.removeAttribute('data-src');
            observer.unobserve(img);
        }
    });
});

lazyImages.forEach(img => imageObserver.observe(img));

// ==================== LANGUAGE SWITCHER ====================
const langBtn = document.getElementById('langBtn');
const langDropdown = document.getElementById('langDropdown');

if (langBtn && langDropdown) {
    langBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        langDropdown.classList.toggle('show');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
        langDropdown.classList.remove('show');
    });

    // Handle language selection
    const langLinks = langDropdown.querySelectorAll('a[data-lang]');
    langLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const lang = link.getAttribute('data-lang');
            const langText = link.textContent.split(' ')[1]; // Get language name
            
            // Update button
            document.getElementById('currentLang').textContent = lang.toUpperCase();
            
            // Store in localStorage
            localStorage.setItem('preferredLanguage', lang);
            
            // Show notification
            console.log(`Language changed to: ${langText}`);
            
            // In production, this would reload content in selected language
            // For now, just close dropdown
            langDropdown.classList.remove('show');
        });
    });

    // Load saved language on page load
    const savedLang = localStorage.getItem('preferredLanguage');
    if (savedLang) {
        document.getElementById('currentLang').textContent = savedLang.toUpperCase();
    }
}

// ==================== WHATSAPP BUTTON ====================
function createWhatsAppButton() {
    const whatsappBtn = document.createElement('a');
    whatsappBtn.href = 'https://wa.me/84797722507';
    whatsappBtn.target = '_blank';
    whatsappBtn.className = 'whatsapp-float';
    whatsappBtn.innerHTML = '<i class="fab fa-whatsapp"></i>';
    whatsappBtn.title = 'Contact us on WhatsApp';
    document.body.appendChild(whatsappBtn);
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
        .whatsapp-float {
            position: fixed;
            bottom: 100px;
            right: 30px;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #25D366;
            color: white;
            border-radius: 50%;
            font-size: 2rem;
            box-shadow: 0 4px 16px rgba(37, 211, 102, 0.4);
            z-index: 998;
            transition: all 0.3s ease;
            animation: pulse 2s ease-in-out infinite;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 24px rgba(37, 211, 102, 0.6);
        }
        
        @keyframes pulse {
            0%, 100% {
                box-shadow: 0 4px 16px rgba(37, 211, 102, 0.4);
            }
            50% {
                box-shadow: 0 4px 24px rgba(37, 211, 102, 0.8);
            }
        }
        
        @media screen and (max-width: 768px) {
            .whatsapp-float {
                bottom: 80px;
                right: 20px;
                width: 50px;
                height: 50px;
                font-size: 1.5rem;
            }
        }
    `;
    document.head.appendChild(style);
}

// Create WhatsApp button - DISABLED (only chat button needed)
// createWhatsAppButton();

console.log('Gettravel - Website loaded successfully!');