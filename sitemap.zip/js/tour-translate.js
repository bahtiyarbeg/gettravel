// ============================================================
//  Google Translate integration for tour detail pages
//  Replaces the non-functional custom language dropdown
// ============================================================

(function() {
    'use strict';

    // ── 1. Inject Google Translate styles ────────────────────
    var style = document.createElement('style');
    style.textContent = [
        '/* ── Google Translate on tour pages ── */',
        '.tour-translate-wrap {',
        '    position: relative;',
        '    margin-left: 12px;',
        '}',
        '.goog-te-banner-frame.skiptranslate { display: none !important; }',
        'body { top: 0 !important; }',
        '.goog-te-gadget-simple {',
        '    background: linear-gradient(135deg,rgba(212,175,55,.2),rgba(212,175,55,.1)) !important;',
        '    border: 2px solid rgba(212,175,55,.45) !important;',
        '    border-radius: 30px !important;',
        '    padding: 7px 16px !important;',
        '    font-size: 0.9rem !important;',
        '    cursor: pointer !important;',
        '    transition: all .25s ease !important;',
        '    display: flex !important;',
        '    align-items: center !important;',
        '    gap: 6px !important;',
        '    white-space: nowrap !important;',
        '}',
        '.goog-te-gadget-simple:hover {',
        '    background: linear-gradient(135deg,rgba(212,175,55,.35),rgba(212,175,55,.2)) !important;',
        '    box-shadow: 0 4px 14px rgba(212,175,55,.3) !important;',
        '}',
        '.goog-te-gadget-simple .goog-te-menu-value {',
        '    color: #fff !important;',
        '    font-weight: 600 !important;',
        '    font-family: inherit !important;',
        '}',
        '.goog-te-gadget-simple .goog-te-menu-value span:first-child {',
        '    color: #fff !important;',
        '}',
        '.goog-te-gadget-simple img { display: none !important; }',
        '.goog-te-gadget-simple [style*="border-left"] { display: none !important; }',
        /* hide "Powered by Google" text */
        '.goog-te-gadget { font-size: 0 !important; }',
        '.goog-te-gadget > span { display: none !important; }',
        '.goog-logo-link { display: none !important; }'
    ].join('\n');
    document.head.appendChild(style);

    // ── 2. Replace the broken dropdown with GT container ─────
    function replaceLangDropdown() {
        var langSelector = document.querySelector('.language-selector');
        if (!langSelector) return;

        var wrap = document.createElement('div');
        wrap.className = 'tour-translate-wrap';

        var gt = document.createElement('div');
        gt.id = 'google_translate_element';
        wrap.appendChild(gt);

        langSelector.parentNode.replaceChild(wrap, langSelector);
    }

    // ── 3. Load Google Translate widget ──────────────────────
    window.googleTranslateElementInit = function() {
        if (typeof google === 'undefined' || !google.translate) return;
        new google.translate.TranslateElement({
            pageLanguage: 'en',
            includedLanguages: 'en,ru,ko,zh-CN,tr,vi,uz',
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
            autoDisplay: false
        }, 'google_translate_element');
    };

    // ── 4. Inject the GT script (only once) ──────────────────
    function loadGTScript() {
        if (document.getElementById('gt-script')) return;
        var s = document.createElement('script');
        s.id  = 'gt-script';
        s.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
        s.async = true;
        document.body.appendChild(s);
    }

    // ── 5. Protect brand name from translation ────────────────
    function protectBrandNames() {
        // All logo links — nav and footer
        document.querySelectorAll('.nav__logo, .footer__logo').forEach(function(el) {
            el.setAttribute('translate', 'no');
            el.classList.add('notranslate');
        });
        // Also protect <html> title attribute if needed
        document.title = document.title; // no-op, title can't be protected via attribute
    }

    // ── 6. Run after DOM ready ────────────────────────────────
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            replaceLangDropdown();
            protectBrandNames();
            loadGTScript();
        });
    } else {
        replaceLangDropdown();
        protectBrandNames();
        loadGTScript();
    }

})();
