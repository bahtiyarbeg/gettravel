/* ============================================================
   GETTRAVEL — GOOGLE ANALYTICS 4 + YANDEX.METRICA
   Unified tracking file for the entire site
   ============================================================ */

// ── Google Analytics 4 ──────────────────────────────────────
window.dataLayer = window.dataLayer || [];
function gtag(){ dataLayer.push(arguments); }
gtag('js', new Date());
// NOTE: Replace G-XXXXXXXXXX with your real GA4 Measurement ID
if (typeof window._ga4Id !== 'undefined') {
    gtag('config', window._ga4Id, {
        page_title: document.title,
        page_location: window.location.href,
        send_page_view: true,
        anonymize_ip: true
    });
}

// ── Yandex.Metrica ──────────────────────────────────────────
(function(m,e,t,r,i,k,a){
    m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
    m[i].l=1*new Date();
    for (var j = 0; j < document.scripts.length; j++) {
        if (document.scripts[j].src === r) { return; }
    }
    k=e.createElement(t), a=e.getElementsByTagName(t)[0];
    k.async=1; k.src=r;
    a.parentNode.insertBefore(k,a)
})(window, document, "script",
    "https://mc.yandex.ru/metrika/tag.js", "ym");

// NOTE: Replace 0 with your real Yandex.Metrica counter ID
var _ymId = window._ymId || 0;
if (_ymId) {
    ym(_ymId, "init", {
        clickmap: true,
        trackLinks: true,
        accurateTrackBounce: true,
        webvisor: true,
        trackHash: true,
        ecommerce: "dataLayer"
    });
}

/* ── Event Tracking ─────────────────────────────────────── */

// Click "Book Tour" button
document.addEventListener('click', function(e) {
    var el = e.target.closest('a[href*="booking"], .booking-submit-btn, .btn-book, [data-track="book"]');
    if (!el) return;
    var tourName = el.dataset.tour || document.title.split('|')[0].trim() || 'Unknown';

    gtag('event', 'begin_checkout', {
        event_category: 'booking',
        event_label: tourName,
        currency: 'USD'
    });
    if (_ymId) ym(_ymId, 'reachGoal', 'booking_click', { tour: tourName });
});

// Click WhatsApp
document.addEventListener('click', function(e) {
    var el = e.target.closest('a[href*="wa.me"], a[href*="whatsapp"]');
    if (!el) return;
    gtag('event', 'contact', { event_category: 'whatsapp', event_label: el.href });
    if (_ymId) ym(_ymId, 'reachGoal', 'whatsapp_click');
});

// Click Viber
document.addEventListener('click', function(e) {
    var el = e.target.closest('a[href*="viber"]');
    if (!el) return;
    gtag('event', 'contact', { event_category: 'viber', event_label: el.href });
    if (_ymId) ym(_ymId, 'reachGoal', 'viber_click');
});

// Tour page view (tour page opened)
if (/tour-.*\.html/.test(window.location.pathname)) {
    var tourPageName = document.title.split('|')[0].trim();
    gtag('event', 'view_item', {
        event_category: 'tour_view',
        event_label: tourPageName,
        items: [{ item_name: tourPageName, item_category: 'tour' }]
    });
    if (_ymId) ym(_ymId, 'reachGoal', 'tour_view', { tour: tourPageName });
}

// Successful booking form submission
document.addEventListener('submit', function(e) {
    var form = e.target.closest('#mainBookingForm, #bookingForm, #tour-form');
    if (!form) return;
    var tourVal = (form.querySelector('#tourSelect') || form.querySelector('#tour-title'));
    var tourName = tourVal ? tourVal.value : document.title.split('|')[0].trim();

    gtag('event', 'purchase', {
        event_category: 'booking_submit',
        event_label: tourName,
        currency: 'USD'
    });
    if (_ymId) ym(_ymId, 'reachGoal', 'booking_submit', { tour: tourName });
});

// Scroll depth tracking (25 / 50 / 75 / 100 %)
(function() {
    var fired = {};
    window.addEventListener('scroll', function() {
        var scrolled = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
        [25, 50, 75, 100].forEach(function(pct) {
            if (scrolled >= pct && !fired[pct]) {
                fired[pct] = true;
                gtag('event', 'scroll', { event_category: 'engagement', event_label: pct + '%' });
                if (_ymId) ym(_ymId, 'reachGoal', 'scroll_depth', { depth: pct });
            }
        });
    }, { passive: true });
})();

/* SETUP INSTRUCTIONS:
   1. Replace G-XXXXXXXXXX with your real Google Analytics 4 Measurement ID
      Example: G-ABC1234567
      Where to get it: analytics.google.com → Admin → Data Streams → ID

   2. Replace XXXXXXXX (3 places) with your real Yandex.Metrica counter number
      Example: 98765432
      Where to get it: metrika.yandex.ru → Counters → counter number
*/
